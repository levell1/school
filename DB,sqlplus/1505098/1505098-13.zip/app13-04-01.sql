CREATE INDEX EC_Product_Company_Inx
ON     EC_PRODUCT(LOWER(Company))
/
