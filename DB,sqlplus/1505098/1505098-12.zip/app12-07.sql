DROP SEQUENCE Order_Seq
/
