SELECT Name, Telephone, Address
FROM   Address_view
ORDER  BY 1
/
