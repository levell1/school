DROP VIEW Address_view
/
