CREATE VIEW Address_view
AS
SELECT UserID, Passwd, Name, Regist_No, Address, Telephone
FROM   EC_Member
/
