INSERT INTO Address_View
VALUES
('arkim','1234','��Ƹ�','990910-2******',NULL,'010-4321-6789')
/
