SELECT COUNT(*)
FROM EC_Member

/
