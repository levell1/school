SELECT Product_Code, Product_Name,Standard, Unit_Price,Left_Qty,Company,Imagename
FROM   EC_Product
WHERE  Product_Code LIKE 'SP%'
/
