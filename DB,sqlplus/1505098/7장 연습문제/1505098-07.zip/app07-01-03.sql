INSERT INTO EC_Product
(Product_Code, Product_Name,Standard, Unit_Price,Left_Qty,Company,Imagename)
VALUES
('SP03','G7 ThinQ','G7+128G',822000,10,'LG����','sp03.jpg')
/
