SELECT Order_No,Product_Code, Order_Qty, Csel,CMoney,CDate
FROM   EC_Order
WHERE  CDate = '18/07/12'
ORDER BY 1 ASC
/
