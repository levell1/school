UPDATE EC_Order
SET    MDate = '18/05/10',	Gubun ='���'
WHERE  Order_No='180505002'
/
