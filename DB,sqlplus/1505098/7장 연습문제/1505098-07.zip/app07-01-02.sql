INSERT INTO EC_Product
(Product_Code, Product_Name,Standard, Unit_Price,Left_Qty,Company,Imagename)
VALUES
('SP02','�����ó�Ʈ','NOTE8+128G',829000,15,'SAMSUNG','sp02.jpg')
/
