SELECT Order_No, Product_Code,Order_Qty, CMoney,MDate,Gubun
FROM   EC_Order
WHERE  MDate = '2018/05/10'
/
