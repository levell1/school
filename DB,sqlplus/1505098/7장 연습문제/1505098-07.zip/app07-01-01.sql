INSERT INTO EC_Product
(Product_Code, Product_Name,Standard, Unit_Price,Left_Qty,Company,Imagename)
VALUES
('SP01','������','IPHONE+54G',816000,10,'APPLE','sp01.jpg')
/
