CREATE TABLE empty_Order
AS
 SELECT *
 FROM   EC_Order
 WHERE  1=2
/
